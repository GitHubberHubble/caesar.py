from setuptools import setup

setup(
    name='caesar',
    version='1.0',
    description='many options for a caesar based en and decryption',
    author='GitHubberHubble',
    url='https://github.com/yourusername/mylibrary',
    packages=['caesar.py', 'caesar.pyi', 'caesar_README.md'],
    install_requires=[
        # List any dependencies here
    ],
)
